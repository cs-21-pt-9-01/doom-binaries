#!/usr/bin/bash

java -Dsun.java2d.d3d=false -cp mochadoom.jar mochadoom.Engine %* -multiply 5 -fullscreen -novert -iwad DOOM.WAD
